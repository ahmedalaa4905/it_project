# Word Underline w/ CSS && clip-path ✨

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/mdXLjzG](https://codepen.io/jh3y/pen/mdXLjzG).

